from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from app.core.config import API_VERSION
from app.web.openapi_catalog import GROUP_META, WEB_GROUPS, get_group_operations

router = APIRouter(tags=["web"])

_TEMPLATES_DIR = Path(__file__).resolve().parents[1] / "templates"
templates = Jinja2Templates(directory=str(_TEMPLATES_DIR))


def _shared_context(request: Request, current_group: str | None = None) -> dict[str, object]:
    return {
        "request": request,
        "group_meta": GROUP_META,
        "groups": WEB_GROUPS,
        "current_group": current_group,
        "current_year": datetime.now(UTC).year,
        "api_version": API_VERSION,
        "seo_description": "Interactive web interface for MLBB Public Data API with endpoint forms, readable response tables, and cURL output.",
        "seo_keywords": "mlbb api, mobile legends api, web ui, fastapi, openapi, response table",
    }


def _normalize_path(value: str) -> str:
    normalized = value.rstrip("/")
    return normalized or "/"


@router.get(path="/", include_in_schema=False, response_class=HTMLResponse)
def landing_page(request: Request) -> HTMLResponse:
    context = _shared_context(request)
    context.update(
        {
            "title": "Home / MLBB Public Data API & Web",
            "web_title": "Home",
            "seo_description": "Modern landing page for MLBB Public Data API. Access docs and a full interactive web playground for all endpoints.",
            "seo_keywords": "mlbb, mobile legends, api docs, web playground, analytics api",
        }
    )
    return templates.TemplateResponse(request, "root/landing_page.html", context)


@router.get(path="/web", include_in_schema=False)
def web_home() -> RedirectResponse:
    return RedirectResponse(url="/web/user", status_code=307)


@router.get(path="/web/{group}", include_in_schema=False, response_class=HTMLResponse)
def web_group_page(request: Request, group: str) -> HTMLResponse:
    if group not in WEB_GROUPS:
        raise HTTPException(status_code=404, detail="Web group not found")

    operations = get_group_operations(request.app, group)
    context = _shared_context(request, current_group=group)
    context.update(
        {
            "title": f"{GROUP_META[group]['title']} Endpoints / MLBB Public Data API & Web",
            "web_title": f"{GROUP_META[group]['title']} Endpoints",
            "subtitle": GROUP_META[group]["description"],
            "seo_description": f"Browse and execute {GROUP_META[group]['title']} endpoints from the MLBB Public Data API & Web interface.",
            "seo_keywords": f"mlbb api, {group} endpoints, openapi web ui",
            "operations": operations,
            "sidebar_operations": operations,
            "selected_web_path": None,
        }
    )
    return templates.TemplateResponse(request, "web/group_page.html", context)


@router.get(path="/web/{group}/{endpoint_path:path}", include_in_schema=False, response_class=HTMLResponse)
def web_endpoint_page(request: Request, group: str, endpoint_path: str) -> HTMLResponse:
    if group not in WEB_GROUPS:
        raise HTTPException(status_code=404, detail="Web group not found")

    all_operations = get_group_operations(request.app, group)
    normalized_path = _normalize_path(f"/web/{group}/{endpoint_path}")
    matched_operations = [
        operation
        for operation in all_operations
        if _normalize_path(str(operation["web_path"])) == normalized_path
    ]

    if not matched_operations:
        raise HTTPException(status_code=404, detail="Web endpoint not found")

    context = _shared_context(request, current_group=group)
    operation_summary = str(matched_operations[0].get("summary") or "Endpoint").strip()
    group_title = str(GROUP_META[group]["title"]).strip()
    context.update(
        {
            "title": f"{operation_summary} - {group_title[:-1] if group_title.endswith('s') else group_title} Endpoint / MLBB Public Data API & Web",
            "web_title": f"{group_title[:-1] if group_title.endswith('s') else group_title} Endpoint",
            "subtitle": "Interactive request form for this API endpoint.",
            "seo_description": f"Execute and inspect a {GROUP_META[group]['title']} endpoint from the MLBB API web interface.",
            "seo_keywords": f"mlbb api endpoint, {group}, curl, readable response",
            "operations": matched_operations,
            "sidebar_operations": all_operations,
            "selected_web_path": normalized_path,
        }
    )
    return templates.TemplateResponse(request, "web/group_page.html", context)
